/**
 * @format
 */

import {AppRegistry} from 'react-native';
import App from './App';
import Acc from './AddOrder';
import {name as appName} from './app.json';




AppRegistry.registerComponent(appName, () =>App);
